# Oblique Parser API

- `GET /health` → `{ ok: true, model: "gpt-4o-mini" | "fallback" }`
- `POST /parseBuyBox` → stable JSON:
